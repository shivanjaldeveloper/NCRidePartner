import { API_BASE_URL, API_BEARER_TOKEN } from './config';

export class ApiError extends Error {
  status?: number;
  raw?: string;

  constructor(message: string, status?: number, raw?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.raw = raw;
  }
}

/**
 * Posts a WebMethod endpoint under partnerauth.asmx as
 * application/x-www-form-urlencoded, matching the curl samples exactly.
 *
 * Confirmed response shape: plain JSON (not XML, not wrapped in `{"d": ...}`)
 * with PascalCase fields — `Result`, `Message`, `OtpTransaction`, `Cookie`,
 * `ProcessingStatus`, etc. The `{"d": ...}` unwrap below is kept as a no-op
 * safety net in case any endpoint behaves differently, but isn't needed for
 * the ones already tested.
 */
export async function postAuthForm<T = any>(
  method: string,
  params: Record<string, string | number | undefined>,
): Promise<T> {
  const body = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined) body.append(key, String(value));
  });

  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}/${method}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Bearer ${API_BEARER_TOKEN}`,
      },
      body: body.toString(),
    });
  } catch (networkErr) {
    throw new ApiError(
      `Network request to ${method} failed. Check connectivity / API reachability.`,
    );
  }

  const raw = await response.text();

  if (!response.ok) {
    throw new ApiError(
      `${method} failed with HTTP ${response.status}`,
      response.status,
      raw,
    );
  }

  try {
    const parsed = JSON.parse(raw);
    // Unwrap ASP.NET ScriptService-style { "d": ... } responses if present.
    return (
      parsed && typeof parsed === 'object' && 'd' in parsed ? parsed.d : parsed
    ) as T;
  } catch {
    throw new ApiError(
      `${method} returned a non-JSON response (likely XML/SOAP). Raw response attached — ` +
        `share this with Claude to fix the parser.`,
      response.status,
      raw,
    );
  }
}
